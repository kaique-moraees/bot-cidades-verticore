from botcity.core import DesktopBot
# Uncomment the line below for integrations with BotMaestro
# Using the Maestro SDK
# from botcity.maestro import *


class Bot(DesktopBot):
    def action(self, execution=None):
        # Uncomment to silence Maestro errors when disconnected
        # if self.maestro:
        #     self.maestro.RAISE_NOT_CONNECTED = False

        # Fetch the Activity ID from the task:
        # task = self.maestro.get_task(execution.task_id)
        # activity_id = task.activity_id

        # Abre o portal Cidades do IBGE
        self.browse("https://cidades.ibge.gov.br/")

        
        if not self.find_text( "buscar", threshold=230, waiting_time=10000):
        self.not_found("buscar")
        self.click()

        # Uncomment to mark this task as finished on BotMaestro
        # self.maestro.finish_task(
        #     task_id=execution.task_id,
        #     status=AutomationTaskFinishStatus.SUCCESS,
        #     message="Task Finished OK."
        # )

        def not_found(self, label):
                print(f"Element not found: {label}")


        if __name__ == '__main__':
            Bot.main()
