# botcidades

projeto de automacao com botcity para a verticore, robo para buscar dados no site do IBGE

